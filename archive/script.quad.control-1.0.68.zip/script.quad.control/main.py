#!/usr/bin/env python3
# -*- coding: utf-8 -*-
import xbmcgui
import xbmcaddon
import os

ADDON = xbmcaddon.Addon()
STATUS_FILE = '/tmp/quad_status'
CMD_FILE = '/tmp/quad_cmd'


def get_s(id):
    return ADDON.getLocalizedString(id) or f"ID:{id}"


class QuadControl(xbmcgui.WindowXML):
    def __init__(self, *args, **kwargs):
        super(QuadControl, self).__init__(*args, **kwargs)
        self.modes = [
            (get_s(30001), 'mode:sq'), (get_s(30002), 'mode:qs'),
            (get_s(30003), 'mode:matrixh'), (get_s(30004), 'mode:stereo4'),
            (get_s(30005), 'mode:dolby'), (get_s(30006), 'mode:pl2'),
            (get_s(30009), 'mode:bypass'), (get_s(30010), 'mode:stereo')
        ]

    def onInit(self):
        try:
            self.container = self.getControl(3001)
            self.container.reset()
            for name, cmd in self.modes:
                self.container.addItem(xbmcgui.ListItem(name))
            self.setFocusId(3001)
            self.update_status()
        except:
            pass

    def update_status(self):
        if os.path.exists(STATUS_FILE):
            try:
                with open(STATUS_FILE, 'r') as f:
                    content = f.read().strip().split('|')
                
                    # quadDSP.py píše "RUN" nebo "STOP"
                    is_running = (content[0] == "RUN")
                
                    if is_running:
                        # Pokud běží, tlačítko 4001 musí nabízet STOP
                        self.getControl(4001).setLabel("STOP ENGINE")
                        status_text = f"QuadDSP: [COLOR green]BĚŽÍ[/COLOR] ({content[1]} {content[2]})"
                    else:
                        # Pokud stojí, tlačítko 4001 musí nabízet START
                        self.getControl(4001).setLabel("START ENGINE")
                        status_text = "QuadDSP: [COLOR red]ZASTAVENO[/COLOR]"
                
                    self.getControl(1001).setLabel(status_text)
            except:
                self.getControl(1001).setLabel("Status: Chyba souboru")

    def onClick(self, controlId):
        # Logika pro tlačítko 4001 (Start/Stop)
        if controlId == 4001:
            label = self.getControl(4001).getLabel()
            if "START" in label:
                self.send_cmd("dsp:start")
            else:
                self.send_cmd("dsp:stop")

        # Logika pro Bitrate a Sampling (ID musí sedět s XML)
        elif controlId == 5001: self.send_cmd("7") # 16bit
        elif controlId == 5002: self.send_cmd("8") # 24bit
        elif controlId == 6001: self.send_cmd("1") # 44.1k
        elif controlId == 6002: self.send_cmd("2") # 48k
        elif controlId == 6003: self.send_cmd("3") # 96k
    
        # Okamžitá obnova stavu po kliknutí
        xbmc.sleep(200) 
        self.update_status()    

    def onAction(self, action):
        if action.getId() in [92, 10, 13]:
            self.close()


if __name__ == '__main__':
    addon_path = ADDON.getAddonInfo('path')
    ui = QuadControl('script-quad-control.xml', addon_path, 'Default', '720p')
    ui.doModal()
    del ui
